function L2_distance=L2(f,g,domain)
% Define the domain of the density functions
% domain = [0:0.05:1]; % Replace start_value, step, and end_value with your specific values

% Calculate the squared differences between the density functions
squared_diff = (f - g).^2;

% Numerically integrate the squared differences using the trapezoidal rule
integral_value = trapz(domain, squared_diff);

% Compute the L2 distance by taking the square root of the integral
L2_distance = sqrt(integral_value);

% Display the result
% disp(['L2 distance: ', num2str(L2_distance)]);