% Read the image
image = imread('meo2.png'); % Replace 'your_image.jpg' with the actual image file name

% Convert the image to grayscale if necessary
if size(image, 3) > 1
    image = rgb2gray(image);
end

% Calculate the histogram
num_bins = 256; % Number of bins for the histogram
histogram = imhist(image, num_bins);

% Normalize the histogram
histogram = histogram / sum(histogram);

% Plot the histogram
figure;
bar(histogram);
title('Histogram');
xlabel('Pixel Intensity');
ylabel('Normalized Frequency');

% Display the estimated density function
figure;
plot(histogram);
title('Estimated Density Function');
xlabel('Pixel Intensity');
ylabel('Density');

