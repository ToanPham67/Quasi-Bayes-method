clear all;
clc;
x=-2:.001:12;
%%%%lop 1
j=0.2;
f=[]
data=[];
% x2=[-2:0.001:200]';
for i=1:50
f(i,:)=pdf('Normal',x,j,1);
j=j+0.05;
end
data=[data;f];
for i=1:50
y=f';
x=x';
 fg1=plot(x,y(:,i),'-.b')
%   pause(.1)
  hold on
end
%%%%%%%lop 2
k=3.5;
for i=1:50
f2(i,:)=pdf('Normal',x,k,1);
k=k+0.05;
end
data=[data;f2];
for i=1:50
y2=f2';
x=x';
  plot(x,y2(:,i),'-.b')
%   pause(.5)
  hold on
end
%%%%%%%lop 3
h=7.5;
for i=1:20
f3(i,:)=pdf('Normal',x,h,1);
h=h+0.06;
end
data=[data;f3];
for i=1:20
y3=f3';
x=x';
  plot(x,y3(:,i),'-.b')
%   pause(.5)
  hold on
end

h1=0.5;
g1=pdf('Normal',x,h1,1);

h2=0.8;
g2=pdf('Normal',x,h2,1);

h3=2.5;
g3=pdf('Normal',x,h3,1);

h4=4.5;
g4=pdf('Normal',x,h4,1);

h5=8;
g5=pdf('Normal',x,h5,1);
data=[data;g1;g2;g3;g4;g5];

x=x';
  hg1=plot(x,g1','-r','LineWidth',2)
  hold on
   plot(x,g2','-r','LineWidth',2)
   hold on
    plot(x,g3','-r','LineWidth',2)
    hold on
     plot(x,g4','-r','LineWidth',2)
     hold on
      plot(x,g5','-r','LineWidth',2)
  pause(.5)
legend([fg1(1,:) hg1],{'PDFs','New PDFs'})
title('125 PDFs Plot')
xlabel('x')
ylabel('f(x) or g(x)')
hold off
 save('data125.mat','data')

tic