clear all;
clc
tic
 x=0:0.01:2.55;
load trainingdata
load testdata
% dataa2=dataa2';
Z=[dataa, dataa2];
figure;
for i=1:160
    d=plot(Z(:,i),'-b');
    hold on
end
for i=161:200
   q=plot(Z(:,i),'-b');
    hold on
end
for i=201:250
   as=plot(Z(:,i),'-r');
    hold on
end
legend([d(1,:) as(1,:)],{'Training data','Test data'})
title('Estimated Density Function');
xlabel('Pixel Intensity');
ylabel('Density');
hold off
%  Z=[Z,Z(:,[5,7,11,16,18,26,45,57,60,61,65,68,70,74,77,82,88,91,102,123,124,128,...
% 131,133,135,140,142,148,150,166,170,178,183,188,190,209,225,240,271,276,280,291,294,295,297,311,317])];
U = initfcm(2,size(Z,2));	
%Tinh phan tu dai dien chum
chieuu=size(U);
for i=1:chieuu(1,1)
fv(:,i)=Z*(U(i,:)'.*U(i,:)')/sum(U(i,:).*U(i,:));
end
fv;
%5 bieu do dai dien
figure;
for i=1:2
x=x';
  gv=plot(x,fv(:,i),'-.b')
%   pause(.5)
  hold on
end
legend(gv,'(fv)representing PDFs')
xlabel('x')
ylabel('fv')
%Tinh ma tran do rong chum
W=[];
for j=1:chieuu(1,2)
    for i=1:chieuu(1,1)
    W(i,j)=L2(fv(:,i),Z(:,j),x);
    end
end
W;
%Cap nhat ma tran phan vung 
   for j=1:chieuu(1,2)
    m=0;
    for k=1:chieuu(1,1)
       if W(k,j)==0
           m=m+1;
       end
    end
    if m==0
    for i=1:chieuu(1,1)
        tong=0;
        for k=1:chieuu(1,1)
        tong=tong+(W(i,j)^2)/(W(k,j)^2);
        end
        Umoi(i,j)=1/tong;
    end
        else
        for l=1:chieuu(1,1)
            if W(l,j)==0
                Umoi(l,j)=1/m;
            else
                Umoi(l,j)=0;
            end
        end
    end
end
Umoi;

%Tinh chuan
chuan=0;
ff=[];
for i=1:chieuu(1,1)
    for j=1:chieuu(1,2)
    lech(i,j)=abs(Umoi(i,j)-U(i,j));
    if lech(i,j)>chuan
        chuan=lech(i,j);
    end
    end
end
chuan;
ff=[ff;chuan]
%lap lai thuat toan cho den khi chuan nho hon exilanh cho truoc, gia su 
% exilanh=0.01
vonglap=1;
while chuan>0.0000000001
    U=Umoi;
%Tinh phan tu dai dien chum
chieuu=size(U);
for i=1:chieuu(1,1)
fv(:,i)=Z*(U(i,:)'.*U(i,:)')/sum(U(i,:).*U(i,:));
end
fv;

%Tinh ma tran do rong chum
W=[];
for j=1:chieuu(1,2)
    for i=1:chieuu(1,1)
    W(i,j)=L2(fv(:,i),Z(:,j),x);
    end
end
W;
%Cap nhat ma tran phan vung 
   for j=1:chieuu(1,2)
    m=0;
    for k=1:chieuu(1,1)
       if W(k,j)==0
           m=m+1;
       end
    end
    if m==0
    for i=1:chieuu(1,1)
        tong=0;
        for k=1:chieuu(1,1)
        tong=tong+(W(i,j)^2)/(W(k,j)^2);
        end
        Umoi(i,j)=1/tong;
    end
        else
        for l=1:chieuu(1,1)
            if W(l,j)==0
                Umoi(l,j)=1/m;
            else
                Umoi(l,j)=0;
            end
        end
    end
end
Umoi;
%Tinh chuan
chuan=0;
for i=1:chieuu(1,1)
    for j=1:chieuu(1,2)
    lech(i,j)=abs(Umoi(i,j)-U(i,j));
    if lech(i,j)>chuan
        chuan=lech(i,j);
    end
    end
end
vonglap=vonglap+1;
end
Umoi;
Fv=fv';
gi = Z(:,[201:250])';
for h=1:size(gi,1)
domain=gi(h,:);
for i=1:k
squared_diff=Fv(i,:);
integral_value (i,h) = 1-trapz(domain, squared_diff);
end
integral_value ;
end
[dc, classify]= max(Umoi(:,[201:250]).*integral_value,[],1)

kqcu=[ones(1,32),ones(1,18)*2];
dung=0;
for i=1:length(kqcu)
if kqcu(:,i)==classify(:,i)
dung=dung+1;
end
end
err=1-dung/length(kqcu)


subplot(2,1,1)
bar(201:250,Umoi(1,[201:250]))
xlabel('Cluster 1');
ylabel('Probability');
hold on
subplot(2,1,2)
bar(201:250,Umoi(2,[201:250]))
xlabel('Cluster 2');
ylabel('Probability');
hold off
toc
% subplot(3,1,3)
% bar(1:125,Umoi(3,:))
% xlabel('Cluster 3');
% ylabel('Probability');