function width=l1(f1,f2,xi);
ttd=abs(f1-f2);
width=sum(ttd)/length(xi)*(max(xi)-min(xi));